// The MealDB API endpoint
const baseURL = "https://www.themealdb.com/api/json/v2/1/";

// Function to fetch recipes by category
async function fetchRecipesByCategory(category) {
  const url = `${baseURL}filter.php?c=${category}`;
  
  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.meals) {
      showResults(data.meals, category);
    } else {
      // Handle the case where no results are found
      const el = document.getElementById(`${category}-results`);
      el.innerHTML = "<p>No results found.</p>";
    }
  } catch (error) {
    console.error("Error fetching data:", error);
  }
}

// Function to fetch breakfast recipes
async function fetchBreakfastRecipes() {
  fetchRecipesByCategory("breakfast");
}

// Function to fetch lunch recipes
async function fetchLunchRecipes() {
  fetchRecipesByCategory("lunch");
}

// Function to fetch dinner recipes
async function fetchDinnerRecipes() {
  fetchRecipesByCategory("dinner");
}


// Function to fetch dessert recipes
async function fetchDessertRecipes() {
  fetchRecipesByCategory("dessert");
}

// Fetch recipes for breakfast, lunch, dinner, and dessert when the page loads
fetchBreakfastRecipes();
fetchLunchRecipes();
fetchDinnerRecipes();
fetchDessertRecipes();

// Function to display results on the respective pages
function showResults(results, category) {
  const containerId = `${category}-results`;

  const el = document.getElementById(containerId);
  el.innerHTML = "";
  for (const result of results) {
    el.insertAdjacentHTML(
      "beforeend",
      `
        <section>
          <img src="${result.strMealThumb}" />
          <p>${result.strMeal}</p>
          <button onclick="showRecipeData('${result.idMeal}', '${category}')"> Show more </button>
        </section>
      `
    );
  }
}

async function showRecipeData(recipeId, category) {
  const url = `${baseURL}lookup.php?i=${recipeId}`;

  try {
    const response = await fetch(url);
    const data = await response.json();
    const meal = data.meals[0];

    const el = document.getElementById(`${category}-results`);
    el.innerHTML = `
      <section>
        <img src="${meal.strMealThumb}" />
        <h2>${meal.strMeal}</h2>
        <h3>Ingredients:</h3>
        <ul>
          ${getIngredientsList(meal)}
        </ul>
        <h3>Instructions:</h3>
        <p>${meal.strInstructions}</p>
        <button onclick="goBackToResults('${category}')"> Back to Results </button>
      </section>
    `;
  } catch (error) {
    console.error("Error fetching data:", error);
  }
}

// Function to create an ingredients list
function getIngredientsList(meal) {
  let ingredientsList = "";
  for (let i = 1; i <= 20; i++) {
    const ingredient = meal[`strIngredient${i}`];
    const measure = meal[`strMeasure${i}`];
    if (ingredient && measure) {
      ingredientsList += `<li>${measure} ${ingredient}</li>`;
    }
  }
  return ingredientsList;
}

// Function to go back to results from details
async function goBackToResults(category) {
  // Fetch recipes again and display results
  await fetchRecipesByCategory(category);
}

// Controls the search function
async function searchForRecipes(event, category) {
  event.preventDefault();
  const term = document.getElementById("term").value;

  // Check if a search term is provided
  if (term) {
    try {
      const response = await fetch(`${baseURL}search.php?s=${term}`);
      const data = await response.json();

      const resultsContainerId = `${category}-results`;

      if (data.meals) {
        showResults(data.meals, category, resultsContainerId);
      } else {
        const el = document.getElementById(resultsContainerId);
        el.innerHTML = "<p>No results found.</p>";
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  } else {
    // Handle the case where no search term is provided
    const el = document.getElementById(resultsContainerId);
    el.innerHTML = "<p>Please enter a search term.</p>";
  }
}


